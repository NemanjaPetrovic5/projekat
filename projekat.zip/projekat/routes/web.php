<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UploadImageController;
use App\Models\Post;
 
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//ZA index i detalje posta
Route::get('/', 'App\Http\Controllers\PostsController@index')->name('posts.index');
Route::get('/posts/details/{id}', 'App\Http\Controllers\PostsController@details')->name('posts.details');

Route::post('/add-to-cart','App\Http\Controllers\CartController@addtocart')->middleware(['auth']);
Route::get('/cart','App\Http\Controllers\CartController@cart')->name('cart')->middleware(['auth']); 
Route::get('/cart/delete/{id}', 'App\Http\Controllers\CartController@delete')->name('cart.delete')->middleware(['auth']);

//naruci
Route::post('/naruci','App\Http\Controllers\OrdersController@naruci')->middleware(['auth']);

// za komentar
Route::get('addcomment','App\Http\Controllers\CommentsController@addcomment')->name('addcomment')->middleware('auth');
Route::post('addcomment','App\Http\Controllers\CommentsController@comment')->name('addcomment')->middleware('auth');

Route::get('/orders','App\Http\Controllers\OrdersController@orders')->name('orders')->middleware(['auth']);
Route::get('/profil','App\Http\Controllers\UserController@profil')->name('profil')->middleware(['auth']);
Route::get('/deleteComment/{id}', 'App\Http\Controllers\UserController@deleteComment')->name('deleteComment')->middleware(['auth']);
//poruka
Route::get('/contact','App\Http\Controllers\MessagesController@contact')->name('contact');
Route::post('/poruka','App\Http\Controllers\MessagesController@poruka');

Route::get('/about','App\Http\Controllers\PostsController@about')->name('about');

//------ADMIN-PANEL-------
Route::get('/admin-panel','App\Http\Controllers\ChartController@chart')->name('admin-panel')->middleware(['can:viewAny,App\Models\Post']);
// za dodavanje NOVOG POSTA
Route::get('admin-posts','App\Http\Controllers\PostsController@admin')->name('admin-posts')->middleware('can:viewAny,App\Models\Post');
Route::get('add','App\Http\Controllers\PostsController@add')->name('posts.add')->middleware('can:create,App\Models\Post');
Route::post('add','App\Http\Controllers\PostsController@insert')->middleware('can:create,App\Models\Post');
//za CRUD posta
Route::get('/posts/edit/{id}', 'App\Http\Controllers\PostsController@edit')->name('posts.edit')->middleware('auth'); 
Route::post('/posts/update/{id}', 'App\Http\Controllers\PostsController@update')->name('posts.update')->middleware(['auth']); 
Route::get('/posts/delete/{id}', 'App\Http\Controllers\PostsController@delete')->name('posts.delete')->middleware(['auth']);

Route::get('/posts/potvrdi/{id}', 'App\Http\Controllers\OrdersController@prihvati')->name('posts.potvrdi')->middleware(['auth']);
Route::get('/posts/odbij/{id}', 'App\Http\Controllers\OrdersController@odbij')->name('posts.odbij')->middleware(['auth']);


Route::get('/admin-users', 'App\Http\Controllers\UserController@users')->name('admin-users')->middleware('can:viewAny,App\Models\User');
// ZA NOVOG USERA
Route::get('dodaj','App\Http\Controllers\UserController@dodaj1')->name('dodaj')->middleware('can:create,App\Models\User');
Route::post('dodaj','App\Http\Controllers\UserController@dodaj')->middleware('can:create,App\Models\User');
//brisanje usera
Route::get('/users/delete/{id}', 'App\Http\Controllers\UserController@delete')->name('users.delete')->middleware(['auth']);

//za gledanje svih narudzbi u admin panelu
Route::get('admin-orders','App\Http\Controllers\OrdersController@admincarts')->name('admin-orders')->middleware('can:viewAny,App\Models\Order');
//brisanje orders
Route::get('/orders/delete/{id}', 'App\Http\Controllers\OrdersController@delete')->name('orders.delete')->middleware(['auth']); 

//komentari na admin panelu svi
Route::get('admin-comments','App\Http\Controllers\CommentsController@comments')->name('admin-comments')->middleware('can:viewAny,App\Models\Comment');
Route::get('/admin-comments/delete/{id}', 'App\Http\Controllers\CommentsController@delete')->name('admin-comments.delete')->middleware(['auth']);

Route::get('admin-messages','App\Http\Controllers\MessagesController@messages')->name('admin-messages')->middleware('can:viewAny,App\Models\Messages');
Route::get('/admin-messages/delete/{id}', 'App\Http\Controllers\MessagesController@delete')->name('admin-messages.delete')->middleware(['auth']);