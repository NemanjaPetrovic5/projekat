<?php

	namespace App\Http\Controllers;
	use App\Models\Post;
	use App\Models\Cart;
	use App\Models\User;
	use App\Models\Comment;
	use Illuminate\Support\Facades\DB;
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Session;

	class PostsController extends Controller
	{		
		public function index(Request $request){
			//fetch all posts data
			// $posts = Post::orderBy('title','desc')->get();
			$posts = Post::paginate(8);

			if($request->has('q')){
				$q = $request->get('q');
				$posts = Post::where('title','LIKE',"%$q%")->orWhere('content','LIKE',"%$q%")->paginate(8);
			} else{
				$posts = Post::paginate(8);
			}

			return view('posts.index', ['posts' => $posts, 'naslov' => "Moj naslov"]);
		}
		public function admin(Request $request){
			// SELECT posts.title,comments.post_id, comments.user_id FROM posts INNER JOIN comments ON posts.id = comments.post_id
			
			$posts = Post::orderBy('title','desc')->get();

			$user_id=$request->user()->id;
			$name = DB::table('users')->where('users.id',$user_id)->get();

			$posts = Post::paginate(8);

			if($request->has('q')){
			    $q = $request->get('q');
			    $posts = Post::where('title','LIKE',"%$q%")->orWhere('content','LIKE',"%$q%")->orWhere('category','LIKE',"%$q%")->paginate(8);
			} else{
			    $posts = Post::paginate(8);
			}
			
			return view('admin-posts', ['posts' => $posts, 'naslov' => "Moj naslov"],['name'=>$name]);
			}
		public function details($id){
			// SELECT * FROM `carts` INNER JOIN users ON carts.user_id = users.id

			$post = Post::find($id);
			$comments = DB::table('posts')
			->join('comments','posts.id','=','comments.post_id')
			->join('users', 'users.id', '=', 'comments.user_id')
			->where('posts.id',$id)->orderBy('comments.id','desc')
			->get();
			//load form view
			return view('posts.details', ['post' => $post],['comments' => $comments]);	
		}
		public function add(Request $request){
			//load form view

			$user_id=$request->user()->id;
			$name = DB::table('users')->where('users.id',$user_id)->get();

			return view('posts.add',['name' => $name]);
		}
		public function insert(Request $request){
	
		$title = $request->title;
	 	$content = $request->content;
	 	$category = $request->category;
	 	$cena = $request->cena;
		
		if($request->file('image')){

			$filename = $request->file('image')->getClientOriginalName();

			$request->file('image')->storeAs('public/uploads' ,$filename);

			$insert = new Post;

			$insert->slika = $filename;
		 	$insert->title = $title;
			$insert->content = $content;
			$insert->category = $category;
			$insert->cena = $cena;
			$insert->user_id=$request->user()->id;
			
			$insert->save();
			Session::flash('success_msg', 'Post added successfully!');

			return redirect()->route('admin-posts');
		}
        // return $request->all();
		Session::flash('error', 'Sva polja su obavezna!');
		return redirect()->route('posts.add');
	}
		public function edit($id,Request $request){
			//get post data by id
			$post =  Post::find($id);
		
			if($request->user()->cannot('update',$post)){
				abort(403);
			}

			$post->user_id=$request->user()->id;

			$comments = DB::table('posts')
			->join('comments','posts.id','=','comments.post_id')
			->join('users', 'users.id', '=', 'comments.user_id')
			->where('posts.id',$id)
			->get();
			//load form view
			return view('posts.edit', ['post' => $post],['comments' => $comments]);
		}
		
		public function update($id, Request $request){

			$p = Post::find($id);
			 if($request->user()->cannot('update',$p)){
				abort(403);
			 }
			$this->validate($request, [
				'title' => 'required',
				'content' => 'required',
				'category' => 'required',
				'cena' => 'required',
			]);
		
			//get post data
		 	$postData = $request->all();
			 $title = $request->title;
			 $content = $request->content;
			 $cena = $request->cena;
			 $category = $request->category;
			 
			if($request->file('image')){
				$postData = $request->all();

				$filename = $request->file('image')->getClientOriginalName();
				$request->file('image')->storeAs('public/uploads' ,$filename);
				$postData['slika'] = "$filename";

				Post::find($id)->update($postData);
			}
			
			Post::find($id)->update($postData);

			Session::flash('error_msg', 'Sva polja su obavezna!');
			Session::flash('success_msg', 'Post updated successfully!');

			return redirect()->route('admin-posts');
			
		}
		public function delete($id,Request $request){
			//Post::find($id)->delete();

			$p = Post::find($id);
			if($request->user()->cannot('delete',$p)){
				abort(403);
			}
			$post = DB::table('posts')->where('id',$id)->delete();
			//store status message
			Session::flash('success_msg', 'Post deleted successfully!');
			return redirect()->route('admin-posts');
		}
		public function about(Request $request){
			return view('about');
		}
}