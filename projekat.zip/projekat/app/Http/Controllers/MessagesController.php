<?php

namespace App\Http\Controllers;

use App\Models\Messages;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Session;

class MessagesController extends Controller
{
    public function contact(Request $request){
        return view('contact');
        }
    public function poruka(Request $request){
        if($request->isMethod('post')){
            $data = $request->all();
            
            $messages = new Messages;
            $messages->name = $data['name'];
            $messages->email = $data['email'];
            $messages->subject = $data['subject'];
            $messages->messages = $data['messages'];
            //echo "<pre>"; print_r($data); die;
            $messages->save();
            
            $message = "Uspešno ste poslsali poruku!";
                session::flash('success_message',$message);

            return redirect()->back();
        }
    }
    public function messages(Request $request){

        $user_id=$request->user()->id;
        $name = DB::table('users')->where('users.id',$user_id)->get();

        $messages = DB::table('messages')->select('messages.id','messages.name','messages.email','messages.subject','messages.messages','messages.created_at')->get();

        if($request->has('q')){
            $q = $request->get('q');
            $messages = Messages::where('name','LIKE',"%$q%")->orWhere('email','LIKE',"%$q%")->orWhere('subject','LIKE',"%$q%")->paginate(10);
        } else{
            $messages = DB::table('messages')->select('messages.id','messages.name','messages.email','messages.subject','messages.messages','messages.created_at')->get();
        }

        return view('admin-messages', ['messages' => $messages],['name'=>$name]);
        }
    public function delete($id,Request $request){
        $p = Messages::find($id);
			if($request->user()->cannot('delete',$p)){
				abort(403);
			}
        $post = DB::table('messages')->where('id',$id)->delete();
        
        //store status message
        Session::flash('success_msg', 'Post deleted successfully!');

        return redirect()->route('admin-messages');
    }
}
