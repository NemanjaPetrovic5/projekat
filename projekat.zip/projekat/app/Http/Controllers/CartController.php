<?php
	namespace App\Http\Controllers;
	use App\Models\Post;
	use App\Models\Cart;
	use App\Http\Controllers\Controller;
	use Illuminate\Support\Facades\DB;
	use Illuminate\Http\Request;
	use Session;

	class CartController extends Controller
	{

		public function addtocart(Request $request){
            if($request->isMethod('post')){
				$data = $request->all();
                //zadavanje sesije
                $session_id = Session::get('session_id');
                if(empty($session_id)){
                    $session_id = Session::getId();
                    Session::put('session_id',$session_id);
                }
            
                $cart = new Cart;
                $cart->session_id = $session_id;
                $cart->posts_id = $data['posts_id'];
                $cart->quantity = $data['quantity'];
                $cart->user_id=$request->user()->id;
                $cart->save();

                $message = "Uspešno ste dodali proizvod u korpu!";
                    session::flash('success_message',$message);

                return redirect()->back();
            }
		}
        public function cart(Request $request){
            //SELECT * FROM `carts` INNER JOIN users ON carts.user_id = users.id
            $user_id=$request->user()->id;

            $post = DB::table('carts')
            ->select('carts.id','carts.user_id','carts.posts_id','carts.quantity','carts.created_at','posts.slika','posts.title','posts.cena','users.name')
			->join('users','carts.user_id','=','users.id')
			->join('posts','carts.posts_id','=','posts.id')
			->where('users.id',$user_id)
			->get();
			//load form view
			return view('posts.cart',['post' => $post]);

        }
        public function delete($id,Request $request){

			$p = Cart::find($id);
			if($request->user()->cannot('delete',$p)){
				abort(403);
			}
			$post = DB::table('carts')->where('id',$id)->delete();
			
			//store status message
			Session::flash('success_msg', 'Post deleted successfully!');

			return redirect()->route('cart');
		}
	}