<?php

	namespace App\Http\Controllers;
	use App\Models\Post;
	use App\Models\Cart;
	use App\Models\Order;
	use App\Http\Controllers\Controller;
	use Illuminate\Support\Facades\DB;
	use Illuminate\Http\Request;
	use Session;

	class OrdersController extends Controller
	{
		public function naruci(Request $request){
            if($request->isMethod('post')){
				$data = $request->all();

                $order = new Order;
                $order->posts_id = $data['posts_id'];
                $order->quantity = $data['quantity'];
                $order->price = $data['price'];
                $order->user_id=$request->user()->id;
                $order->stanje = $data['stanje'];
                //echo "<pre>"; print_r($data); die;
                $order->save();
                
                $message = "Uspešno ste narucili ovaj proizvod!";
                    session::flash('success_message',$message);

                return redirect()->back();
            }
		}
        public function orders(Request $request){
            // $post =  User::find($id);
            //SELECT * FROM `carts` INNER JOIN users ON carts.user_id = users.id
            $user_id=$request->user()->id;

            $name = DB::table('users')->where('users.id',$user_id)->get();

            $post = DB::table('orders')
            ->select('orders.user_id','orders.posts_id','orders.quantity','orders.created_at','orders.stanje','posts.id','orders.id','posts.slika','posts.title','posts.cena','orders.price','users.name')
			->join('users','orders.user_id','=','users.id')
			->join('posts','orders.posts_id','=','posts.id')
			->where('users.id',$user_id)
			->get();
			//load form view
			return view('orders',['post' => $post],['name' => $name ]);
        }
        public function admincarts(Request $request){
            // SELECT posts.title,comments.post_id, comments.user_id FROM posts INNER JOIN comments ON posts.id = comments.post_id
    
            $user_id=$request->user()->id;
            $name = DB::table('users')->where('users.id',$user_id)->get();
    
            $posts = DB::table('posts')
            ->select('orders.user_id','orders.posts_id','orders.quantity','orders.created_at','orders.stanje','posts.id','orders.id','posts.slika','posts.title','posts.cena','orders.price','users.name')
            ->join('orders','posts.id','=','orders.posts_id')
            ->join('users', 'users.id', '=', 'orders.user_id')
            ->orderBy('stanje')
            ->get();
    
            return view('admin-orders', ['posts' => $posts, 'naslov' => "Moj naslov"],['name'=>$name]);
        }
        public function prihvati($id, Request $request){

            $order = Order::find($id);
            $stanje = $request->title;
            $stanje=DB::table('orders')->where('id',$id)->update(['stanje'=>'prihvaceno']);
        
            Session::flash('success_msg', 'Prihvatili ste narudzbinu!');
            return redirect()->route('admin-orders');
        }
        public function odbij($id, Request $request){

            $order = Order::find($id);
            $stanje = $request->title;
            $stanje=DB::table('orders')->where('id',$id)->update(['stanje'=>'odbijeno']);
        
            Session::flash('success_msg', 'Odbili ste narudzbinu!');
            return redirect()->route('admin-orders');
        }
        public function delete($id,Request $request){

            $p = Order::find($id);
			if($request->user()->cannot('delete',$p)){
				abort(403);
			}
			$post = DB::table('orders')->where('id',$id)->delete();
			
			//store status message
			Session::flash('success_msg', 'Obrisali ste narudzbinu!');
			return redirect()->route('admin-orders');
		}
	}