<?php

namespace App\Http\Controllers;
use App\Models\Post;
use App\Models\Comment;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Session;

class CommentsController extends Controller
{
    public function addcomment(){
        //load form view
        return view('addcomment');
    }
    public function comment(Request $request){
    // echo "<pre>"; print_r($data); die;
    $comments = $request->comments;
    $post_id = $request->post_id;

    $insert = new Comment;
    $insert->user_id=$request->user()->id;
    $insert->post_id = $post_id;
    $insert->comments = $comments;
    
        $insert->save();
        Session::flash('success_msg', 'Post added successfully!');
        return redirect()->back();
    }
    public function comments(Request $request){
        //SELECT comments.id,comments.comments,comments.created_at,posts.title,users.name,users.email FROM comments
        //INNER JOIN posts ON comments.post_id = posts.id INNER JOIN users ON comments.user_id = users.id

        $user_id=$request->user()->id;
        $name = DB::table('users')->where('users.id',$user_id)->get();

         $comments = DB::table('comments')
         ->select('comments.id','comments.comments','comments.created_at','posts.title','users.name','users.email')
         ->join('posts','comments.post_id','=','posts.id')
         ->join('users', 'comments.user_id', '=', 'users.id')
         ->get();

        return view('admin-comments', ['comments' => $comments, 'naslov' => "Moj naslov"],['name'=>$name]);
        }
    public function delete($id,Request $request){
        $p = Comment::find($id);
        if($request->user()->cannot('delete',$p)){
            abort(403);
        }
        $post = DB::table('comments')->where('id',$id)->delete();
        
        //store status message
        Session::flash('success_msg', 'Post deleted successfully!');

        return redirect()->route('admin-comments');
    }
}
