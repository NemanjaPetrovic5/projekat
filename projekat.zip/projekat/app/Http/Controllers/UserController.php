<?php

	namespace App\Http\Controllers;
	use App\Models\Post;
	use App\Models\Cart;
	use App\Models\User;
	use App\Models\Comment;
    use Illuminate\Support\Facades\Hash;
    use Illuminate\Support\Facades\Validator;
    use Illuminate\Validation\Rule;
	use App\Http\Controllers\Controller;
	use Illuminate\Support\Facades\DB;
	use Illuminate\Http\Request;
	use Session;

	class UserController extends Controller
	{
        public function profil(Request $request){
            // $post =  User::find($id);
            //SELECT * FROM `carts` INNER JOIN users ON carts.user_id = users.id
            $user_id=$request->user()->id;

            $name = DB::table('users')->where('users.id',$user_id)->get();
            $post = DB::table('orders')
            ->select('orders.user_id','orders.posts_id','orders.quantity','orders.created_at','posts.id','orders.id','orders.price','orders.stanje','posts.slika','posts.title','posts.cena','users.name')
			->join('users','orders.user_id','=','users.id')
			->join('posts','orders.posts_id','=','posts.id')
			->where('users.id',$user_id)
			->get();

            $com = DB::table('comments')
            ->select('comments.user_id','comments.post_id','comments.created_at','comments.comments','posts.id','comments.id','posts.slika','posts.title','posts.cena','users.name')
			->join('users','comments.user_id','=','users.id')
			->join('posts','comments.post_id','=','posts.id')
			->where('users.id',$user_id)
			->get();
			//load form view
			return view('profil',['post' => $post],['name' => $name ,'com' => $com]);
        }
        public function users(Request $request){
        //fetch all posts data
            $users = User::orderBy('type','asc')->get();

			if($request->has('q')){
				$q = $request->get('q');
				$users = User::where('name','LIKE',"%$q%")->orWhere('email','LIKE',"%$q%")->orWhere('type','LIKE',"%$q%")->paginate(20);
			} else{
				$users = User::orderBy('type','asc')->get();
			}

            $user_id=$request->user()->id;
            $name = DB::table('users')->where('users.id',$user_id)->get();

        return view('admin-users', ['users' => $users, 'naslov' => "Moj naslov"],['name'=>$name]);
        }
        public function dodaj1(Request $request) {
            $user_id=$request->user()->id;

            $name = DB::table('users')->where('users.id',$user_id)->get();
            //load form view
            return view('dodaj',['name'=>$name]);
            
        }
        public function dodaj(Request $request){
            
            $this->validate($request,[
                'name' => ['required', 'string', 'max:255'],
                'email' => [
                    'required',
                    'string',
                    'email',
                    'max:255',
                    Rule::unique(User::class),
                    'password' => ['required', 'string'],
            ]]);
            //get post data
            $name = $request-> name;
            $email = $request-> email;
            $password = $request-> password;
            $type = $request-> type;

            $insert = new User;

                $insert->name = $name;
                $insert->email = $email;
                $insert->password = Hash::make($password);
                $insert->type = $type;

            $insert->save();
            
            //store status message
            Session::flash('success_msg', 'User added successfully!');

            return redirect()->route('admin-users');
        }
        public function delete($id,Request $request){
            // Post::find($id)->delete();
            $post = DB::table('users')->where('id',$id)->delete();
            $users =  Comment::find($id);
                
            if($request->user()->cannot('delete',$users)){
                abort(403);
            }
            //store status message
            Session::flash('success_msg', 'User deleted successfully!');
            return redirect()->route('admin-users');
        }
        public function deleteComment($id,Request $request){
            // Post::find($id)->delete();
            $com =  Comment::find($id);
                
            if($request->user()->cannot('delete',$com)){
                abort(403);
            }
            $post = DB::table('comments')->where('id',$id)->delete();
            
            //store status message
            Session::flash('success_msg', 'Comment deleted successfully!');

            return redirect()->route('profil');
        }
	}