
<?php $__env->startSection('content'); ?>

<div class="container mt-5 mb-5">
<img src="<?php echo e(asset('storage/images/biblioteka.jpg')); ?>" width="100%" height="650px" alt="about" width="150px" class="mb-4">

<p><b>Lanac Knjižare</b><p> nastao je u junu 2010. godine pod sloganom „Erupcija ideja“. 

U Beogradu se nalazi petnaest od ukupno trideset i dve knjižara (Knez Mihailova, Beo SC, Kulturni centar Beograda, Ušće Shopping Center, Delta City, TC Merkator, SC Stadion Voždovac, RK Zvezda Zemun, Sremska 2, SC Rajićeva, Bulevar Tašmajdan, Bulevar City Store, SC Big Fashion, Beteks Banovo brdo, Ada Mall, Big Rakovica, Beo SC). Ostalih sedamnaest knjižara nalazi se širom Srbije i to u Nišu, Novom Sadu, Zrenjaninu, Čačku, Kragujevcu, Šapcu, Užicu, Kruševcu i Pančevu.
</p><p>
Osnovu naše ponude čine knjige svih domaćih izdavača. Vodili smo se idejom da čitalačkoj publici na jednom mestu ponudimo kvalitetan izbor. Možete birati  beletristiku, stručnu literaturu, popularnu nauku, umetnost, enciklopedijska izdanja, dečje knjige, naučnu i epsku fantastiku, sve što poželite da čitate u zavisnosti od Vaših afiniteta.

Ono što nas čini drugačijim je veliki izbor knjiga na stranim jezicima iz oblasti arhitekture, dizajna, umetnosti, grafičkog dizajna. U prilici ste da pronađete i veliki broj svetskih hitova koji još nisu prevedeni na srpski jezik.

U nasim možete pronaći i bogat gift program, kao i papirnu galanteriju, širok izbor kancelarijskog materijala, muziku. 
</p><p>
Nase knjizare potrudiće se da vam pomognu da živite bogatije i zadovoljnije kroz zabavu, obrazovanje i inspiraciju!
</p>
 
<p>
<b>Broj telefona:</b> 017 251 1901
</p><p>
<b>Adresa:</b> Sremska 62 11000 Beograd
</p><p>
<b>E-mail:</b> knjizara@knjizara.rs
</p><p>
<b>Račun:</b> Banka Intesa 106-336484-06
</p><p>
<b>Šifra delatnosti:</b> 5234
</p><p>
<b>PIB:</b> 106651341
</p><p>
<b>Matični broj:</b> 20644834</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nemanja\Desktop\projekat\resources\views/about.blade.php ENDPATH**/ ?>