

<?php $__env->startSection('content'); ?>

<main class="mt-5 pt-4">
    <div class="container">
        <div class="card ">
            <div class="card-header">
            <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h5 class="card-title"><?php echo e($n->name); ?> - Narucene knjige </h5>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <table class="table table-striped card-table table-condensed mt-0 table-nowrap border">
                        <thead>
                            <tr>
                                <th>Slika</th>
                                <th>Naziv</th>
                                <th>Kolicina</th>
                                <th>Datum narudzbe</th>
                                <th>Za placanje</th>
                                <th>Stanje</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $total = 0; ?>
                        <?php $quantity = 0; ?>

                        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <img src="<?php echo e(asset('storage/uploads/' . $post->slika)); ?>  " width="50px" height="50px" alt=""> </td>
                                <td><?php echo e($post->title); ?></td>
                                <td><?php echo e($post->quantity); ?></td>
                                <td><?php echo e(date('d.m.Y H:i', strtotime($post->created_at))); ?></td>
                                <td><?php echo e($post->price); ?>.00 din</td>
                                <td><?php echo e($post->stanje); ?></td>
                            </tr>
                            <?php $total = $total + ($post->cena * $post->quantity) ?>
                            <?php $quantity = $quantity + $post->quantity ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td colspan=12 style="text-align: right">Ukupno za placanje:  <?php echo e($total); ?>.00 din</td> 
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat\resources\views/orders.blade.php ENDPATH**/ ?>