

<?php $__env->startSection('title'); ?>
    <a class="navbar-brand text-success h1" href="">
    <?php echo e('Admin-panel-Messages'); ?>

    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('naslov'); ?>
    <h2><?php echo e('Messages'); ?></h2>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-body">
			<div class="d-lg-flex align-items-center mb-4 gap-3">
				<div class="position-relative">
					<form action="<?php echo e(route('messages')); ?>" method="get" role="search">
                        <!-- <?php echo e(csrf_field()); ?> -->
                        <div class="input-group">
                            <input type="text" class="form-control ps-5 radius-30 mx-3" name="q" placeholder="Search Users">
                            <span class="input-group-btn">
                            <button type="submit" class="btn btn-primary">Search
                            </button>
                            </span>
                        </div>
                    </form>
				</div>
			</div>
			<div class="table-responsive">
				<table class="table mb-0 table table-striped card-table table-condensed table-nowrap border">
					<thead class="table-light">
						<tr>
							<th>Name</th>
							<th>Email</th>
							<th>Subject</th>
							<th>Messages</th>
							<th>Date created</th>
							<th>Actions</th>
						</tr>
					</thead>
					<tbody>	
					<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($message->name); ?></td>
							<td><?php echo e($message->email); ?></td>
							<td><?php echo e($message->subject); ?></td>
							<td><?php echo e($message->messages); ?></td>
							<td><?php echo e(date('d.m.Y H:i', strtotime($message->created_at))); ?></i><br/></td>
							<td><a href="<?php echo e(route('messages.delete', $message->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a>	
						</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat\resources\views/messages.blade.php ENDPATH**/ ?>