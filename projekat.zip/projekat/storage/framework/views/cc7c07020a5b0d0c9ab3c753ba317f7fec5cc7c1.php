

<?php $__env->startSection('title'); ?>
    <a class="navbar-brand text-success h1" href="">
    <?php echo e('Admin-panel-Posts'); ?>

    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('naslov'); ?>
    <h2><?php echo e('Posts'); ?></h2>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-body">
			<div class="d-lg-flex align-items-center mb-4 gap-3">
				<div class="position-relative">
                <form action="<?php echo e(route('admin-posts')); ?>" method="get" role="search">
                        <!-- <?php echo e(csrf_field()); ?> -->
                        <div class="input-group">
                            <input type="text" class="form-control ps-5 radius-30 mx-3" name="q" placeholder="Search Posts">
                            <span class="input-group-btn">
                            <button type="submit" class="btn btn-primary">Search
                            </button>
                            </span>
                        </div>
                    </form>
				</div>
				<div class="ms-auto"><a href="<?php echo e(route('posts.add')); ?>" class="btn btn-primary radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Add New Post</a></div>
			</div>
			<div class="table-responsive">
            <?php if(Session::has('error_message')): ?>
                            <div class="alert alert-danger">
                              <?php echo e(Session::get('error_message')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('success_msg')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('success_msg')); ?>

                            </div>
                        <?php endif; ?>
				<table class="table mb-0 table table-striped card-table table-condensed table-nowrap border m-6">
					<thead class="table-light">
                        <tr>
                            <th>Slika</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Date created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
					<tbody>
					<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
                            <td><img src="<?php echo e(asset('storage/uploads/' . $post->slika)); ?>  " width="120px" height="100px" alt=""></td>
                            <td><?php echo e($post->title); ?></td>
                            <td><?php echo e($post->category); ?></td>
                            <td><?php echo e($post->cena); ?>.00 din</td>
                            <td><?php echo e(date('d.m.Y H:i', strtotime($post->created_at))); ?></i><br/></td>
                            <td>
                            <?php if(Auth::user()->can('update', $post)): ?>
                                <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-warning">Edit</a>
                            <?php endif; ?> 
                            <?php if(Auth::user()->can('delete', $post)): ?>
                                <a href="<?php echo e(route('posts.delete', $post->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a>
                            <?php endif; ?>
                            </td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
    <!--Pagination-->
    <nav class="d-flex justify-content-center wow fadeIn mt-4">
        <ul class="pagination pg-blue">
        <?php echo $posts->appends(Request::all())->links(); ?>

        </ul>
    </nav>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nemanja\Desktop\projekat\resources\views/admin-posts.blade.php ENDPATH**/ ?>