

<?php $__env->startSection('content'); ?>

    <section class="bg-light">
        <div class="container pb-5">
            <div class="row">
                <div class="col-lg-5 mt-5">
                    <div class="card mb-3">
                    <img src="<?php echo e(asset('storage/uploads/' . $post->slika)); ?>  " width="100%" height="450px" alt=""> 
                    </div>
                    <div class="row"></div>
                </div>
                <div class="col-lg-7 mt-5">
                    <div class="card">
                        <div class="card-body">
                          <?php if(Session::has('error_message')): ?>
                            <div class="alert alert-danger">
                              <?php echo e(Session::get('error_message')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('success_message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('success_message')); ?>

                            </div>
                        <?php endif; ?>
                            <h1 class="h2"><?php echo e($post->title); ?></h1>
                            <p class="h3 py-2">Cena: <?php echo e($post->cena); ?>.00 din</p>
                            <p class="py-2">
                                <span class="list-inline-item text-dark">Rating 4.8 | 36 Comments</span>
                            </p>
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <h6>Category:</h6>
                                </li>
                                <li class="list-inline-item">
                                    <p class="text-muted"><strong><?php echo e($post->category); ?></strong></p>
                                </li>
                            </ul>
                            <h6>Description:</h6>
                            <p><?php echo e($post->content); ?></p>
                        <form action="<?php echo e(url('add-to-cart')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="posts_id" value="<?php echo e($post->id); ?>">
                            <div class="row pb-3">
                                <div class="col d-grid">
                                    <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-danger btn-lg pl-6"style="height: 50px;margin-top:50px;"> Back</a>
                                </div>
                                <div class="col d-grid">
                                    <input name="quantity" type="number" value="1" class="span1" style="width: 60px; height:50px; " required>
                                    <button type="submit" class="btn btn-success btn-lg">Add To Cart</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="container dark-grey-text">
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data" id="upload-image" action="<?php echo e(route('addcomment')); ?>" >
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Komentar:</label>
                        <div class="col-sm-10">
                            <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                            <textarea type="text" name="comments" id="comments" class="form-control mb-2"></textarea>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                    </div>
                </div>     
            </form>
        </div>
        <?php if(!count($comments)==0): ?>
        <h4 class="mt-2">Komentari:</h4>
        <hr>
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <i style="font-size: 12px"><?php echo e(date('d.m.Y H:i', strtotime($comment->created_at))); ?></i><br/>
            <?php echo e($comment->comments); ?>  
        <br>
            <?php echo e($comment->name); ?> 
        <hr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <div class="comment">
            <h4>Komentari:</h4>
            <hr>
            <p>Nema komentara</p>
        </div>
      <?php endif; ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nemanja\Desktop\projekat\resources\views/posts/details.blade.php ENDPATH**/ ?>