

<?php $__env->startSection('title'); ?>
    <a class="navbar-brand text-success h1" href="">
    <?php echo e('Admin-panel-Add post'); ?>

    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-wrapper">
			<div class="page-content">
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3 h3">Add new post</div>
                </div>
			</div>
			<div class="card">
				<div class="card-body">
					<div class="d-lg-flex align-items-center">
						<div class="ms-auto"><a href="<?php echo e(route('admin-posts')); ?>" class="btn btn-primary radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Back</a></div>
					</div>
					<div class="table-responsive">
                        <div class="card-body">
                            <form method="POST" enctype="multipart/form-data" id="upload-image" action="<?php echo e(route('posts.add')); ?>" >
                            <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="control-label col-sm-2 " >Title</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="title" id="title" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2 mt-3" >Content</label>
                                            <div class="col-sm-10">
                                                <textarea name="content" id="content" class="form-control"></textarea>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="control-label col-sm-2 " >Category</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="category" id="category" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2 mt-3" >Cena</label>
                                            <div class="col-sm-10">
                                                <input type="number" name="cena" id="cena" class="form-control">
                                            </div>
                                        </div>
                                            
                                        <div class="form-group mt-3">
                                            <input type="file" name="image" placeholder="Choose image" id="image">
                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                        <?php if(Session::has('error')): ?>
                                            <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary mt-3" id="submit">Submit</button>
                                    </div>
                                </div>     
                            </form>
                        </div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat\resources\views/posts/add.blade.php ENDPATH**/ ?>