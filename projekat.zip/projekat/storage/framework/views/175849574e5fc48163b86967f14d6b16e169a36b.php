
<div class="container mt-5">
 
  <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
  <?php endif; ?>
 
  <div class="card">
 
    <div class="card-header text-center font-weight-bold">
      <h2>Laravel 8 Upload Image Tutorial</h2>
    </div>
 
    <div class="card-body">
        <form method="POST" enctype="multipart/form-data" id="upload-image" action="<?php echo e(route('addcomment')); ?>" >
        <?php echo csrf_field(); ?>
            <div class="row">
            
 
                <div class="col-md-12">
       
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Komentar</label>
                        <div class="col-sm-10">
                            <textarea name="comments" id="comments" class="form-control"></textarea>
                        </div>
                    </div>
                    
                
                   
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                </div>
            </div>     
        </form>
      
    </div>
 
  </div>
 
</div>  
</body>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat\resources\views/addcomment.blade.php ENDPATH**/ ?>