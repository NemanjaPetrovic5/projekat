

<?php $__env->startSection('title'); ?>
    <a class="navbar-brand text-success h1" href="">
    <?php echo e('Admin-panel-Posts'); ?>

    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('naslov'); ?>
    <h2><?php echo e('Posts'); ?></h2>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-body">
			<div class="d-lg-flex align-items-center mb-4 gap-3">
				<div class="position-relative">
					<input type="text" class="form-control ps-5 radius-30" placeholder="Search Users"> <span class="position-absolute top-50 product-show translate-middle-y"><i class="bx bx-search"></i></span>
				</div>
				<div class="ms-auto"><a href="<?php echo e(route('posts.add')); ?>" class="btn btn-primary radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Add New Post</a></div>
			</div>
			<div class="table-responsive">
				<table class="table mb-0">
					<thead class="table-light">
                        <tr>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Date created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
					<tbody>
					<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
                            <td><?php echo e($post->title); ?></td>
                            <td><?php echo e($post->category); ?></td>
                            <td><?php echo e($post->cena); ?>.00 din</td>
                            <td><?php echo e(date('d.m.Y H:i', strtotime($post->created_at))); ?></i><br/></td>
                            <td>
                                <a href="<?php echo e(route('posts.details', $post->id)); ?>" class="btn btn-primary">View Details</a>
                                <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-warning">Edit</a>
                            <?php if(Auth::user()->can('delete', $post)): ?>
                                <a href="<?php echo e(route('posts.delete', $post->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a>
                            <?php endif; ?>
                            </td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat\resources\views/admin.blade.php ENDPATH**/ ?>