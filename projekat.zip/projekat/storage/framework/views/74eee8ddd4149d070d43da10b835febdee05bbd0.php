

<?php $__env->startSection('title'); ?>
    <a class="navbar-brand text-success h1" href="">
    <?php echo e('Admin-panel-Orders'); ?>

    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('naslov'); ?>
    <h2><?php echo e('Orders'); ?></h2>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="d-lg-flex align-items-center mb-4 gap-3">
                
            </div>
            <div class="table-responsive">
            <?php if(Session::has('error_message')): ?>
                            <div class="alert alert-danger">
                              <?php echo e(Session::get('error_message')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('success_msg')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('success_msg')); ?>

                            </div>
                        <?php endif; ?>
                <table class="table mb-0 table table-striped card-table table-condensed table-nowrap border m-6">
                    <thead class="table-light">
                        <tr>
                            <th>Slika</th>
                            <th>Post title</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Date created</th>
                            <th>Status</th>
                            <th>Opcion</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><img src="<?php echo e(asset('storage/uploads/' . $p->slika)); ?>  " width="120px" height="100px" alt=""></td>

                            <td><?php echo e($p->title); ?></td>
                            <td><?php echo e($p->name); ?></td>
                            <td><?php echo e($p->cena); ?>.00 din</td>
                            <td><?php echo e($p->quantity); ?></td>
                            <td><?php echo e(date('d.m.Y H:i', strtotime($p->created_at))); ?></i><br/></td>
                            <td><?php echo e($p->stanje); ?></td>
                            <td>    
                                <a href="<?php echo e(route('posts.potvrdi', $p->id)); ?>" class="btn btn-primary btn-sm radius-30 px-4"name="stanje" id="">Potvrdi</a>
                                <a href="<?php echo e(route('posts.odbij', $p->id)); ?>" class="btn btn-warning btn-sm radius-30 px-4"name="stanje" id="">Odbij</a>
                            </td>
                            <td><a href="<?php echo e(route('orders.delete', $p->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a></td>	
                        </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat\resources\views/admin-orders.blade.php ENDPATH**/ ?>