@extends('layouts.app')

@section('content')

<main class="mt-5 pt-4">
    <div class="container">
        <div class="card ">
            <div class="card-header">
            @foreach($name as $n)
            <h5 class="card-title">{{ $n->name }} - Narucene knjige </h5>
            @endforeach
                <div class="row">
                    <table class="table table-striped card-table table-condensed mt-0 table-nowrap border">
                        <thead>
                            <tr>
                                <th>Slika</th>
                                <th>Naziv</th>
                                <th>Kolicina</th>
                                <th>Datum narudzbe</th>
                                <th>Za placanje</th>
                                <th>Stanje</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $total = 0; ?>
                        <?php $quantity = 0; ?>

                        @foreach($post as $post)
                            <tr>
                                <td> <img src="{{asset('storage/uploads/' . $post->slika)}}  " width="50px" height="50px" alt=""> </td>
                                <td>{{$post->title}}</td>
                                <td>{{$post->quantity}}</td>
                                <td>{{date('d.m.Y H:i', strtotime($post->created_at))}}</td>
                                <td>{{$post->price}}.00 din</td>
                                <td>{{$post->stanje}}</td>
                            </tr>
                            <?php $total = $total + ($post->cena * $post->quantity) ?>
                            <?php $quantity = $quantity + $post->quantity ?>
                            @endforeach
                            <td colspan=12 style="text-align: right">Ukupno za placanje:  {{$total}}.00 din</td> 
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection