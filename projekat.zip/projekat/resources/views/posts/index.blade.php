@extends('layouts.app')

@section('content')
  <main>
    <div class="container">
      <nav class="navbar navbar-expand-lg mt-3 mb-5">
      
       
        <form action="{{ route('posts.index') }}" method="get" role="search">
          <!-- {{ csrf_field() }} -->
          <div class="input-group">
            <input type="text" class="form-control" style="width:300px;height:50px;margin-right:5px;"name="q" placeholder="Search">
            <span class="input-group-btn">
            <button type="submit" style="height:50px" class="btn btn-primary">Search
            </button>
            </span>
          </div>
        </form>
      </nav>
    <div class="container">
      <div class="row">
        @foreach($posts as $post)
          <div class="col-lg-3 col-md-6 mb-4">
              <div class="card h-100">
              <a href="{{ route('posts.details', $post->id) }}">
                <img src="{{asset('storage/uploads/' . $post->slika)}}  " width="100%" height="250px" alt="">
              </a>
              <div class="card">
                  <div class="card-body ml-6">
                      <h3 class="card-title ms-5"><a class="text-decoration-none" href="{{ route('posts.details', $post->id) }}">{{$post->title}}</a></h3>
                      <h5 style="margin-left:60px">Cena: {{$post->cena}}.00 din</h5>
                  </div>
                  <div class="mb-3">
                  <a href="{{ route('posts.details', $post->id) }}" class="btn btn-success col-md-6 col-6 col-form-label  mt-3 offset-md-3 offset-3">Details</a>
              </div>
              </div>
              </div>
          </div>
        @endforeach
      <!--Pagination-->
      <nav class="d-flex justify-content-center wow fadeIn">
        <ul class="pagination pg-blue">
        {!! $posts->appends(Request::all())->links() !!}
        </ul>
        </nav>
    </div>
  </main>
@endsection