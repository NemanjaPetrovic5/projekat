
<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--favicon-->
	<!--plugins-->
	
	
	<!-- Bootstrap CSS -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    


    
    <title>Admin-panel-Users</title>
</head>

<body style=" font-family: Arial, Helvetica, sans-serif;
background-color: #f1f1f1;
position: relative;
padding-bottom: 58px;
min-height: 100vh;
">

    <div id="app">
        <!-- <nav class="navbar navbar-expand-md navbar-dark bg-primary"> -->
        <nav class="navbar navbar-expand-lg navbar-light shadow">


            <div class="container-fluid"style="margin-left:80px">
            <a class="navbar-brand text-success h1" href="">
                {{  'Admin-panel-Edit' }}
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('admin-panel') }}">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('admin-posts') }}">Postovi</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('admin-orders') }}">Narudbine</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('admin-users') }}">Users</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('admin-comments') }}">Comments</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('admin-messages') }}">Messages</a>
                        </li>
                    </ul>
                </div>
                <!-- Example split danger button -->

                <!-- Right Side Of Navbar -->
  
               
                <a class="d-flex align-items-center nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="user-info ps-3">
				
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="{{ route('admin-panel') }}">Dashboard</a>
                            </li>
                            <li><a class="dropdown-item" href="{{ route('admin-posts') }}">Postovi</a>
                            </li>
                            <li><a class="dropdown-item" href="{{ route('admin-orders') }}">Narudzbine</a>
                            </li>
                            <li>
                                <div class="dropdown-divider mb-0"></div>
                            </li>
                            <li><a class="dropdown-item" href="{{ route('logout') }}"
                                onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                {{ __('Logout') }}
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="page-wrapper">
			<div class="page-content">
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3 h3">Edit post</div>
                </div>
			</div>
			<div class="card">
                <div class="card-body">
                    <div class="d-lg-flex align-items-center gap-3">
                        <div class="ms-auto"><a href="{{ route('admin-posts') }}" class="btn btn-primary radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Back</a></div>
                        </div>
                    <div class="table-responsive">
                   
                        <div class="panel panel-default">
                        <div class="panel-body">
                        @if(Session::has('error_msg'))
                            <div class="alert alert-danger">
                              {{ Session::get('error_message') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                        @if(Session::has('success_message'))
                            <div class="alert alert-success">
                                {{ Session::get('success_message') }}
                            </div>
                        @endif
                            <form action="{{ route('posts.update', $post->id) }}" enctype="multipart/form-data" method="POST" class="form-horizontal">
                            {{ csrf_field() }}
                                <div class="form-group">
                                    <label class="control-label col-sm-2 mt-2" >Title</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="title" id="title" class="form-control" value="{{ $post->title }}">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2 mt-2" >Content</label>
                                    <div class="col-sm-10">
                                        <textarea name="content" id="content" class="form-control">{{ $post->content }}</textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2 mt-2" >Category</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="category" id="category" class="form-control" value="{{ $post->category }}">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2 mt-2" >Cena</label>
                                    <div class="col-sm-10">
                                        <input type="number" name="cena" id="cena" class="form-control" value="{{ $post->cena }}">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2 mt-2" >Slika</label><br>
                                    <img src="{{asset('storage/uploads/' . $post->slika)}}  " width="200px" height="220px" alt=""> 
                                    <div class="col-sm-10">
                                    
                                        <input type="file" name="image" id="image" class="form-control mt-2" value="{{ $post->slika }}">
                                    </div>
                                </div>
                            
                                <div class="form-group mt-4 text-center">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <input type="submit" class="btn btn-success" value="Update Post" />
                                    </div>
                                </div>
                            </form>
                        </div>
					</div>
				</div>
			</div>
		</div>
	</div>
    <footer style="text-align: center;
      background-color: #333;
      color: #fff;
      margin-left:-632px;
      padding: 20px;
      position: absolute;
      bottom: 0;
      width: 100%;">
        <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script>, Nemanja Petrović</p>
      </footer>
</body>
</html>