@extends('layouts.app-admin')

@section('title')
    <a class="navbar-brand text-success h1" href="">
    {{  'Admin-panel-Add post' }}
    </a>
@endsection

@section('content')
    <div class="container">
        <div class="page-wrapper">
			<div class="page-content">
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3 h3">Add new post</div>
                </div>
			</div>
			<div class="card">
				<div class="card-body">
					<div class="d-lg-flex align-items-center">
						<div class="ms-auto"><a href="{{ route('admin-posts') }}" class="btn btn-primary radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Back</a></div>
					</div>
					<div class="table-responsive">
                        <div class="card-body">
                            <form method="POST" enctype="multipart/form-data" id="upload-image" action="{{ route('posts.add') }}" >
                            @csrf
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="control-label col-sm-2 " >Title</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="title" id="title" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2 mt-3" >Content</label>
                                            <div class="col-sm-10">
                                                <textarea name="content" id="content" class="form-control"></textarea>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="control-label col-sm-2 " >Category</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="category" id="category" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2 mt-3" >Cena</label>
                                            <div class="col-sm-10">
                                                <input type="number" name="cena" id="cena" class="form-control">
                                            </div>
                                        </div>
                                            
                                        <div class="form-group mt-3">
                                            <input type="file" name="image" placeholder="Choose image" id="image">
                                        @error('image')
                                            <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                                        @enderror
                                        
                                        </div>
                                        @if(Session::has('error'))
                                            <div class="alert alert-danger">{{ Session::get('error') }}</div>
                                        @endif
                                    </div>
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary mt-3" id="submit">Submit</button>
                                    </div>
                                </div>     
                            </form>
                        </div>
					</div>
				</div>
			</div>
		</div>
	</div>
@endsection
