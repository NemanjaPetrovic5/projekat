@extends('layouts.app')

@section('content')
    <main class="mt-5 pt-4 mb-5">
        <div class="container">
            <div class="card ">
                <div class="card-header">
                    <h5 class="card-title">Korpa</h5>
                <div class="row">
                @if(Session::has('error_message'))
                            <div class="alert alert-danger">
                              {{ Session::get('error_message') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                        @if(Session::has('success_message'))
                            <div class="alert alert-success">
                                {{ Session::get('success_message') }}
                            </div>
                        @endif
                    <table class="table table-striped card-table table-condensed mt-0 table-nowrap border">
                        <thead>
                            <tr>
                                <th>Slika</th>
                                <th>Ime</th>
                                <th>Naziv proizvoda</th>
                                <th>Količina</th>
                                <th>Dodato u korpu</th>
                                <th>Cena</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $total = 0; ?>
                        <?php $quantity = 0; ?>
                        @foreach($post as $post)
                            <tr>
                                <td> <img src="{{asset('storage/uploads/' . $post->slika)}}  " width="50px" height="50px" alt=""></td>
                                <td>{{$post->name}}</td>
                                <td>{{$post->title}}</td>
                                <td><input name="quantity" type="number"  class="span1" placeholder="{{$post->quantity}}"  style="width: 50px " required></td>
                                <td>{{$post->created_at}}</td>
                                <td>{{$post->cena}}.00 din</td>
                                <td><a href="{{ route('cart.delete', $post->id) }}" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a></td>
                            
                            </tr>
                            <?php $total = $total + ($post->cena * $post->quantity) ?>
                            <?php $quantity = $quantity + $post->quantity ?>

                            @endforeach
                            <td colspan=12 style="text-align: right">Ukupno za placanje:  {{$total}}.00 din</td>
                        </tbody>
                    </table>
                    @if(!empty($post->posts_id))
                    <form colspan=12 style="text-align: right" action="{{ url('naruci') }}" method="post" enctype="multipart/form-data">
                        {{ csrf_field() }}
                    
                        <input type="hidden" name="posts_id" value="{{ $post->posts_id }}">
                        <input type="hidden" name="quantity" value="{{ $quantity }}">
                        <input type="hidden" name="price" value="{{ $total }}">
                        <input type="hidden" name="stanje" value="na cekanju">

                        <button class="btn btn-primary btn-md my-0 p" type="submit">Naruci
                            <i class="fas fa-shopping-cart ml-1"></i>
                        </button>
                    </form>
                    @endif
                </div>
            </div>
        </div>
    </main>
@endsection