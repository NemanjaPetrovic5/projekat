<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'Knjizara') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    <!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script> -->
    
</head>
<body style=" font-family: Arial, Helvetica, sans-serif;
background-color: #f1f1f1;
position: relative;
padding-bottom: 58px;
min-height: 100vh;
">

    <nav class="navbar navbar-expand-lg navbar-light d-none d-lg-block" style="background-color: #333;">
        <div class="container text-light">
            <div class="w-100 d-flex justify-content-between">
                <div>
                    <a class="text-light text-decoration-none" href="#">knjizara@knjizara.com</a>
                    <a class="text-light text-decoration-none" href="#">010-020-0340</a>
                </div>
                
            </div>
        </div>
    </nav>
    <div id="app">
        <nav class="navbar navbar-expand-lg navbar-light shadow">
        <div class="container">
            <a class="navbar-brand text-success h1" href="{{ url('/') }}">{{  'Knjižara' }}</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('posts.index') }}">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('about') }}">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('contact') }}">Contact</a>
                        </li> 
                    </div>
                    <div class="d-flex">
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="nav navbar-nav">
     
                    @auth
                        <li class="nav-item active">
                            <a class="nav-link text-dark" href="{{ route('cart') }}">Cart</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link text-dark" href="{{ route('orders') }}">Orders</a>
                        </li>
                    @endauth
                    @guest
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('login') }}">{{ __('Login') }}</a>
                        </li>
                    @if (Route::has('register'))
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="{{ route('register') }}">{{ __('Register') }}</a>
                        </li>
                    @endif
                    @else
                    <div class="dropdown">
                            <button class="btn btn-primary dropdown-toggle nav-link dropdown-toggle text-white" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                        {{ Auth::user()->name }}
                            </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                            <li class="dropdown-item"><a class="nav-link text-dark" href="{{ route('profil') }}">{{ __('Profil') }}</a></li>
                            <li class="dropdown-item">
                                <a class="nav-link text-dark" href="{{ route('logout') }}"
                                onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                {{ __('Logout') }}
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                                </a>
                            </li>
                            @endguest
                        </ul>
                     </div>
                </div>
            </div>
        </div>
    </nav>

    <main style="margin-bottom:50px;">
        @yield('content')
    </main>
    <footer style="text-align: center;
      background-color: #333;
      color: #fff;
      padding: 20px;
      position: absolute;
      bottom: 0;
      width: 100%;">
        <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script>, Nemanja Petrović</p>
      </footer>
</body>
</html>