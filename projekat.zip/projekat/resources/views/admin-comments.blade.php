@extends('layouts.app-admin')

@section('title')
    <a class="navbar-brand text-success h1" href="">
    {{  'Admin-panel-Comments' }}
    </a>
@endsection
@section('naslov')
    <h2>{{  'Comments' }}</h2>
@endsection

@section('content')
	<div class="card">
		<div class="card-body">
			<div class="d-lg-flex align-items-center mb-4 gap-3">
			</div>
			<div class="table-responsive">
				<table class="table mb-0 table table-striped card-table table-condensed table-nowrap border">
                    <thead class="table-light">
                        <tr>
                            <th>Title</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Comment</th>
                            <th>Date created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
					@foreach($comments as $comment)
                        <tr>
                            <td>{{$comment->title }}</td>
                            <td>{{$comment->name}}</td>
                            <td>{{$comment->email}}</td>
                            <td>{{$comment->comments}}</td>
                            <td>{{date('d.m.Y H:i', strtotime($comment->created_at))}}</i><br/></td>
                            <td><a href="{{ route('admin-comments.delete', $comment->id) }}" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a></td>
                        </tr>
                    @endforeach
                    </tbody>
				</table>
			</div>
		</div>
	</div>
@endsection