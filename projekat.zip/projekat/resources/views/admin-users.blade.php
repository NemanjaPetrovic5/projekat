@extends('layouts.app-admin')

@section('title')
    <a class="navbar-brand text-success h1" href="">
    {{  'Admin-panel-Users' }}
    </a>
@endsection
@section('naslov')
    <h2>{{  'Users' }}</h2>
@endsection

@section('content')
    <div class="card">
		<div class="card-body" >
			<div class="d-lg-flex align-items-center mb-4 gap-3" >
				<div class="position-relative">
                    <form action="{{ route('admin-users') }}" method="get" role="search">
                        <!-- {{ csrf_field() }} -->
                        <div class="input-group">
                            <input type="text" class="form-control ps-5 radius-30 mx-3" name="q" placeholder="Search Users">
                            <span class="input-group-btn">
                            <button type="submit" class="btn btn-primary">Search
                            </button>
                            </span>
                        </div>
                    </form>
				</div>
				<div class="ms-auto"><a href="{{ route('dodaj') }}" class="btn btn-primary radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Add New User</a></div>
            </div>
				<div class="table-responsive" >
					<table class="table mb-0 table table-striped card-table table-condensed table-nowrap border m-6">
						<thead class="table-light">
							<tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Type</th>
                                <th>Date created</th>
                                <th>Actions</th>
							</tr>
						</thead>
						<tbody>
						@foreach($users as $user)
							<tr>
                                <td>{{ $user->name }}</td>
                                <td>{{$user->email}}</td>
                                <td><div class="text-success bg-light-success p-2 text-uppercase px-3"><b>{{$user->type}}</b></div></td>
                                <td>{{date('d.m.Y H:i', strtotime($user->created_at))}}</i><br/></td>
                                <td><a href="{{ route('users.delete', $user->id) }}" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a>	
                            </tr>
						@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
@endsection
