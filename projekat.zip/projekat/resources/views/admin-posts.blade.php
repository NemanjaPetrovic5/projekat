@extends('layouts.app-admin')

@section('title')
    <a class="navbar-brand text-success h1" href="">
    {{  'Admin-panel-Posts' }}
    </a>
@endsection
@section('naslov')
    <h2>{{  'Posts' }}</h2>
@endsection
@section('content')
	<div class="card">
		<div class="card-body">
			<div class="d-lg-flex align-items-center mb-4 gap-3">
				<div class="position-relative">
                <form action="{{ route('admin-posts') }}" method="get" role="search">
                        <!-- {{ csrf_field() }} -->
                        <div class="input-group">
                            <input type="text" class="form-control ps-5 radius-30 mx-3" name="q" placeholder="Search Posts">
                            <span class="input-group-btn">
                            <button type="submit" class="btn btn-primary">Search
                            </button>
                            </span>
                        </div>
                    </form>
				</div>
				<div class="ms-auto"><a href="{{ route('posts.add') }}" class="btn btn-primary radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Add New Post</a></div>
			</div>
			<div class="table-responsive">
            @if(Session::has('error_message'))
                            <div class="alert alert-danger">
                              {{ Session::get('error_message') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                        @if(Session::has('success_msg'))
                            <div class="alert alert-success">
                                {{ Session::get('success_msg') }}
                            </div>
                        @endif
				<table class="table mb-0 table table-striped card-table table-condensed table-nowrap border m-6">
					<thead class="table-light">
                        <tr>
                            <th>Slika</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Date created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
					<tbody>
					@foreach($posts as $post)
						<tr>
                            <td><img src="{{asset('storage/uploads/' . $post->slika)}}  " width="120px" height="100px" alt=""></td>
                            <td>{{$post->title}}</td>
                            <td>{{$post->category}}</td>
                            <td>{{$post->cena}}.00 din</td>
                            <td>{{date('d.m.Y H:i', strtotime($post->created_at))}}</i><br/></td>
                            <td>
                            @if (Auth::user()->can('update', $post))
                                <a href="{{ route('posts.edit', $post->id) }}" class="btn btn-warning">Edit</a>
                            @endif 
                            @if (Auth::user()->can('delete', $post))
                                <a href="{{ route('posts.delete', $post->id) }}" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a>
                            @endif
                            </td>
						</tr>
					@endforeach
					</tbody>
				</table>
			</div>
		</div>
	</div>
    <!--Pagination-->
    <nav class="d-flex justify-content-center wow fadeIn mt-4">
        <ul class="pagination pg-blue">
        {!! $posts->appends(Request::all())->links() !!}
        </ul>
    </nav>
@endsection